#pragma once 


#ifndef __RAZE_NAMESPACE_BEGIN
#define __RAZE_NAMESPACE_BEGIN namespace raze {
#endif // __RAZE_NAMESPACE_BEGIN

#ifndef __RAZE_NAMESPACE_END
#define __RAZE_NAMESPACE_END }
#endif // __RAZE_NAMESPACE_END



#ifndef __RAZE_ARCH_NAMESPACE_BEGIN
#define __RAZE_ARCH_NAMESPACE_BEGIN namespace raze { namespace arch {
#endif // __RAZE_ARCH_NAMESPACE_BEGIN

#ifndef __RAZE_ARCH_NAMESPACE_END
#define __RAZE_ARCH_NAMESPACE_END }}
#endif // __RAZE_ARCH_NAMESPACE_END



#ifndef __RAZE_ALGORITHM_NAMESPACE_BEGIN 
#define __RAZE_ALGORITHM_NAMESPACE_BEGIN namespace raze { namespace algorithm {
#endif // __RAZE_ALGORITHM_NAMESPACE_BEGIN

#ifndef __RAZE_ALGORITHM_NAMESPACE_END
#define __RAZE_ALGORITHM_NAMESPACE_END }}
#endif // __RAZE_ALGORITHM_NAMESPACE_END



#ifndef __RAZE_TRAITS_NAMESPACE_BEGIN 
#define __RAZE_TRAITS_NAMESPACE_BEGIN namespace raze { namespace traits {
#endif // __RAZE_TRAITS_NAMESPACE_BEGIN

#ifndef __RAZE_TRAITS_NAMESPACE_END
#define __RAZE_TRAITS_NAMESPACE_END }}
#endif // __RAZE_TRAITS_NAMESPACE_END



#ifndef __RAZE_MATH_NAMESPACE_BEGIN 
#define __RAZE_MATH_NAMESPACE_BEGIN namespace raze { namespace math {
#endif // __RAZE_MATH_NAMESPACE_BEGIN

#ifndef __RAZE_MATH_NAMESPACE_END
#define __RAZE_MATH_NAMESPACE_END }}
#endif // __RAZE_MATH_NAMESPACE_END



#ifndef __RAZE_VX_NAMESPACE_BEGIN 
#define __RAZE_VX_NAMESPACE_BEGIN namespace raze { namespace vx {
#endif // __RAZE_VX_NAMESPACE_BEGIN

#ifndef __RAZE_VX_NAMESPACE_END
#define __RAZE_VX_NAMESPACE_END }}
#endif // __RAZE_VX_NAMESPACE_END



#ifndef __RAZE_MEMORY_NAMESPACE_BEGIN 
#define __RAZE_MEMORY_NAMESPACE_BEGIN namespace raze { namespace memory {
#endif // __RAZE_MEMORY_NAMESPACE_BEGIN

#ifndef __RAZE_MEMORY_NAMESPACE_END
#define __RAZE_MEMORY_NAMESPACE_END }}
#endif // __RAZE_MEMORY_NAMESPACE_END



#ifndef __RAZE_CONCURRENCY_NAMESPACE_BEGIN 
#define __RAZE_CONCURRENCY_NAMESPACE_BEGIN namespace raze { namespace concurrency {
#endif // __RAZE_CONCURRENCY_NAMESPACE_BEGIN

#ifndef __RAZE_CONCURRENCY_NAMESPACE_END
#define __RAZE_CONCURRENCY_NAMESPACE_END }}
#endif // __RAZE_CONCURRENCY_NAMESPACE_END



#ifndef __RAZE_SYSTEM_NAMESPACE_BEGIN 
#define __RAZE_SYSTEM_NAMESPACE_BEGIN namespace raze { namespace system {
#endif // __RAZE_SYSTEM_NAMESPACE_BEGIN

#ifndef __RAZE_SYSTEM_NAMESPACE_END
#define __RAZE_SYSTEM_NAMESPACE_END }}
#endif // __RAZE_SYSTEM_NAMESPACE_END



#ifndef __RAZE_OPTIONS_NAMESPACE_BEGIN 
#define __RAZE_OPTIONS_NAMESPACE_BEGIN namespace raze { namespace options {
#endif // __RAZE_OPTIONS_NAMESPACE_BEGIN

#ifndef __RAZE_OPTIONS_NAMESPACE_END
#define __RAZE_OPTIONS_NAMESPACE_END }}
#endif // __RAZE_OPTIONS_NAMESPACE_END



#ifndef __RAZE_OPTIONS_CONCEPTS_NAMESPACE_BEGIN 
#define __RAZE_OPTIONS_CONCEPTS_NAMESPACE_BEGIN namespace raze { namespace options { namespace concepts {
#endif // __RAZE_OPTIONS_CONCEPTS_NAMESPACE_BEGIN

#ifndef __RAZE_OPTIONS_CONCEPTS_NAMESPACE_END
#define __RAZE_OPTIONS_CONCEPTS_NAMESPACE_END }}}
#endif // __RAZE_OPTIONS_CONCEPTS_NAMESPACE_END



#ifndef __RAZE_COMPATIBILITY_NAMESPACE_BEGIN 
#define __RAZE_COMPATIBILITY_NAMESPACE_BEGIN namespace raze { namespace compatibility { 
#endif // __RAZE_COMPATIBILITY_NAMESPACE_BEGIN

#ifndef __RAZE_COMPATIBILITY_NAMESPACE_END
#define __RAZE_COMPATIBILITY_NAMESPACE_END }}
#endif // __RAZE_COMPATIBILITY_NAMESPACE_END