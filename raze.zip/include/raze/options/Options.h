// This part of the API was inspired by the EVE project.
// The implementation has been adapted for raze::vx.

#pragma once 

#include <src/raze/options/Aggregator.h>
#include <src/raze/options/As.h>
#include <src/raze/options/Call.h>
#include <src/raze/options/Callable.h>
#include <src/raze/options/Concepts.h>
#include <src/raze/options/ConditionalCallable.h>
#include <src/raze/options/DecoratedWith.h>
#include <src/raze/options/Drop.h>
#include <src/raze/options/Fetch.h>
#include <src/raze/options/Foldable.h>
#include <src/raze/options/Functor.h>
#include <src/raze/options/IgnoreNone.h>
#include <src/raze/options/Keys.h>
#include <src/raze/options/Keywords.h>
#include <src/raze/options/Merge.h>
#include <src/raze/options/Option.h>
#include <src/raze/options/Options.h>
#include <src/raze/options/SelectKeys.h>
#include <src/raze/options/Settings.h>
#include <src/raze/options/DispatchCall.h>
#include <src/raze/options/TypeOr.h>
#include <src/raze/options/Traits.h>
#include <src/raze/options/Unroller.h>
