#pragma once 

#include <raze/algorithm/find/Find.h>

__RAZE_ALGORITHM_NAMESPACE_BEGIN

template <class _Traits_>
struct _Search_n : _Traits_ {
	template <class _Iterator_, class _Sentinel_, class _Size_,
		class _ValueType_, class Predicate, class Projection>
	struct __impl {
		_Iterator_ _iterator;
		_Sentinel_ _sentinel;
		_Size_ _count;
		_Size_ _current_count;
		_ValueType_ _value;
		Predicate _predicate;
		Projection _proj;
		_Iterator_ _candidate;

		constexpr explicit __impl(_Iterator_ __it, _Sentinel_ __sent, _Size_ __count,
			const _ValueType_& __value, Predicate __pred, Projection __proj) noexcept: 
			_iterator(__it), _sentinel(__sent), _count(__count), _current_count(0),
			_value(__value), _predicate(__pred), _proj(__proj), _candidate(__it)
		{}

		template <class _Tag_>
		raze_always_inline constexpr bool operator()(_Tag_) noexcept {
			if (_count <= 0) return true;
			if (_iterator == _sentinel) return true;

			if (_predicate(_proj(*_iterator), _value)) {
				if (_current_count == 0) _candidate = _iterator;

				++_current_count;
				++_iterator;

				return _current_count == _count;
			}

			_current_count = 0;
			++_iterator;
			return false;
		}

		raze_always_inline constexpr std::ranges::subrange<_Iterator_> result() const noexcept {
			if (_count <= 0) return std::ranges::subrange(_candidate, _candidate);
			if (_current_count >= _count) return std::ranges::subrange(_candidate, _iterator);

			return std::ranges::subrange(_iterator, _iterator);
		}
	};

	template <class _Tag_>
	struct __vectorized_search_n {
		template <class _Iterator_, class _Sentinel_, class _Value_, 
			class _SizeType_, class Predicate, class Projection>
		raze_nodiscard raze_always_inline std::ranges::subrange<_Iterator_> operator()(_Iterator_ __first, 
			_Sentinel_ __sentinel, _SizeType_ __count, const _Value_& __v, Predicate __predicate, 
			Projection __proj) const noexcept
		{
			if (__count <= 0)
				return { __first, __first };

			for (; __first != __sentinel; ++__first) {
				if (__predicate(__proj(*__first), __v)) {
					auto __start = __first;
					auto __n = _SizeType_(1);

					for (;;) {
						if (__n++ == __count) return { __start, std::ranges::next(__first) };
						if (++__first == __sentinel) return { __first, __first };
						if (!__predicate(__proj(*__first), __v)) break;
					}
				}
			}

			return { __first, __first };
		}

		template <class _Iterator_, class _Sentinel_, class _SizeType_,
			class _ValueType_, class Predicate, class Projection>
		raze_nodiscard raze_always_inline std::ranges::subrange<_Iterator_>
			operator()(sizetype __aligned_size, sizetype __tail_size, _Iterator_ __first,
				_Sentinel_ __sentinel, _SizeType_ __count, const _ValueType_& __v,
				Predicate __predicate, Projection __proj) const noexcept requires(vx::simd_type<_Tag_>)
		{
			auto* __ptr = std::to_address(__first);
			auto* __aligned_end = __bytes_pointer_offset(__ptr, __aligned_size);

			auto __current_count = _SizeType_(0);

			do {
				auto __mask = __predicate(__proj(vx::load<_Tag_>(__ptr)), __v);

				if (vx::none_of(__mask)) {
					__current_count = 0;
					__advance_bytes(__ptr, sizeof(_Tag_));
					continue;
				}

				i32 __from = -1;

				while (true) {
					auto __begin = vx::find_next_set[vx::not_null](__mask, __from);

					if (__begin == _Tag_::size()) break;
					if (__current_count != 0 && __begin != 0) __current_count = 0;

					const auto __end = std::min<i32>(__begin + (__count - __current_count), _Tag_::size());

					if (vx::is_contiguous(__mask, __begin, __end)) {
						__current_count += (__end - __begin);

						if (__current_count >= __count) {
							auto* __result = (__current_count == (__end - __begin)) ? (__ptr + __begin) : (__ptr + __end - __count);

							__seek_iter(__first, __result);
							__seek_iter(__sentinel, __result + __count);

							return { __first, __sentinel };
						}

						goto __next;
					}

					__current_count = 0;
					__from = __begin;
				}

				__next:
					__advance_bytes(__ptr, sizeof(_Tag_));
			} while (__ptr != __aligned_end);

			__seek_iter(__first, __ptr - __current_count);
			return (*this)(__first, __sentinel, __count, __v, __predicate, __proj);
		}
	};

	template <std::input_iterator _Iterator_, std::sentinel_for<_Iterator_> _Sentinel_,
		class _Value_, class Predicate = std::equal_to<>, class Projection = std::identity>
	raze_nodiscard constexpr raze_always_inline std::ranges::subrange<_Iterator_> operator()(_Iterator_ __first,
		_Sentinel_ __last, std::iter_difference_t<_Iterator_> __count, const _Value_& __v,
		Predicate __pred = {}, Projection __proj = {}) const noexcept
            requires (std::indirectly_comparable<_Iterator_, const _Value_*, Predicate, Projection>)
	{
		if (raze_unlikely(__count <= 0)) return { __first, __first };
		else if (__count == 1) {
			auto __r = algorithm::find_if(std::move(__first), __last, [&__v](auto __x) raze_always_inline_lambda{
				return __x == __v; }, traits::fwd_fn(__proj));

			return { __r, __r != __last ? std::ranges::next(__r) : __r };
		}
		else {
			auto __r = __search_n_unchecked(traits::__uiter<_Sentinel_>(std::move(__first)),
				traits::__usent<_Iterator_>(std::move(__last)), __count, __v,
				traits::fwd_fn(__pred), traits::fwd_fn(__proj));

			__seek_iter(__first, __r.begin());
			__seek_iter(__last, __r.end());

			return { __first, __last };
		}
	}

	template <std::ranges::input_range Range, class _Value_,
		class Predicate = std::equal_to<>, class Projection = std::identity>
	constexpr raze_always_inline std::ranges::borrowed_subrange_t<Range> operator()(
		Range&& __range, std::ranges::range_difference_t<Range> __count, 
		const _Value_& __v, Predicate __pred = {}, Projection __proj = {}) const noexcept
			requires(!constexpr_sized_range<Range> && std::indirectly_comparable<
				std::ranges::iterator_t<Range>, const _Value_*, Predicate, Projection>)
	{
		auto __first = std::ranges::begin(__range);
		auto __last = std::ranges::end(__range);

		if (raze_unlikely(__count <= 0)) return { __first, __first };
		else if (__count == 1) {
			auto __r = algorithm::find_if(std::move(__first), __last, [&__v] (auto __x) raze_always_inline_lambda {
				return __x == __v; }, traits::fwd_fn(__proj));

			return { __r, __r != __last ? std::ranges::next(__r) : __r };
		}
		else {
			auto __r = __search_n_unchecked(traits::__r_uiter<Range>(std::move(__first)),
				traits::__r_usent<Range>(std::move(__last)),
				__count, __v, traits::fwd_fn(__pred),
				traits::fwd_fn(__proj));

			__seek_iter(__first, __r.begin());
			__seek_iter(__last, __r.end());

			return { __first, __last };
		}
	}

	template <std::ranges::input_range Range, class _Value_,
		class Predicate = std::equal_to<>, class Projection = std::identity>
	constexpr raze_always_inline std::ranges::borrowed_subrange_t<Range> operator()(
		Range&& __range, std::ranges::range_difference_t<Range> __count,
		const _Value_& __v, Predicate __pred = {}, Projection __proj = {}) const noexcept
			requires(constexpr_sized_range<Range> && std::indirectly_comparable<
				std::ranges::iterator_t<Range>, const _Value_*, Predicate, Projection>)
	{
		auto __first = std::ranges::begin(__range);
		auto __last = std::ranges::end(__range);

		if (raze_unlikely(__count <= 0)) return { __first, __first };
		else if (__count == 1) {
			auto __r = algorithm::find_if(std::forward<Range>(__range), [&__v](auto __x) raze_always_inline_lambda{
				return __x == __v; }, traits::fwd_fn(__proj));

			return { __r, __r != __last ? std::ranges::next(__r) : __r };
		}
		else {
			auto __r = __search_n_unchecked(traits::__r_uiter<Range>(std::move(__first)),
				traits::__r_usent<Range>(std::move(__last)),
				__count, __v, traits::fwd_fn(__pred), traits::fwd_fn(__proj),
				std::integral_constant<sizetype, __range_constexpr_size<Range>()>{});

			__seek_iter(__first, __r.begin());
			__seek_iter(__last, __r.end());

			return { __first, __last };
		}
	}
private:
	template <class _Iterator_, class _Sentinel_, class _ValueType_, 
		class _SizeType_, class Predicate, class Projection>
	raze_nodiscard constexpr raze_always_inline std::ranges::subrange<_Iterator_> __search_n_unchecked(_Iterator_ __first, 
		_Sentinel_ __last, _SizeType_ __count, const _ValueType_& __v, Predicate __pred,
		Projection __proj) const noexcept
	{
		__verify_range(__first, __last);
		
		using _TraitsType = decltype(this->traits());
		using _Value_ = std::iter_value_t<_Iterator_>;

		if constexpr (!options::always_scalar<_TraitsType>() && std::contiguous_iterator<_Iterator_> 
			&& vectorizable_binary_predicate<Predicate, _Iterator_> &&
			vectorizable_projection<Projection, _Iterator_>)
		{
			if not consteval {
				const auto __size = algorithm::distance(__first, __last);
				if (raze_unlikely(__size < __count)) return { __last, __last };
				return vx::__dispatch_sized_impl<__vectorized_search_n, _Value_, std::ranges::subrange<_Iterator_>>(
					__size * sizeof(_Value_), __first, __last, __count, __v, __pred, __proj);
			}
		}
		
		return options::_unroller_t<decltype(this->traits()), vx::scalar_tag>(__impl(__first, __last, __count, __v, __pred, __proj));
	}

	template <class _Iterator_, class _Sentinel_, class _ValueType_,
		class _SizeType_, class Predicate, class Projection, sizetype _Size_>
	raze_nodiscard constexpr raze_always_inline std::ranges::subrange<_Iterator_> __search_n_unchecked(_Iterator_ __first,
		_Sentinel_ __last, _SizeType_ __count, const _ValueType_& __v, Predicate __pred,
		Projection __proj, std::integral_constant<sizetype, _Size_>) const noexcept
	{
		__verify_range(__first, __last);

		using _TraitsType = decltype(this->traits());
		using _Value_ = std::iter_value_t<_Iterator_>;

		if constexpr (!options::always_scalar<_TraitsType>() && std::contiguous_iterator<_Iterator_>
			&& vectorizable_binary_predicate<Predicate, _Iterator_>
			&& vectorizable_projection<Projection, _Iterator_>)
		{
			if not consteval {
				return vx::__dispatch_sized_impl<__vectorized_search_n, _Value_, std::ranges::subrange<_Iterator_>>(
					std::integral_constant<sizetype, _Size_ * sizeof(_Value_)>{}, __first, __last, __count, __v, __pred, __proj);
			}
		}
		
		return options::_unroller_t<_TraitsType, vx::scalar_tag>(__impl(__first, __last, __count, __v, __pred, __proj));
	}
};

constexpr inline auto search_n = raze::options::function_with_traits<_Search_n>;

__RAZE_ALGORITHM_NAMESPACE_END
