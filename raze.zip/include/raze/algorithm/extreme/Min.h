#pragma once 


#include <src/raze/algorithm/RangesSize.h>
#include <src/raze/algorithm/VectorizablePredicate.h>
#include <src/raze/algorithm/EqualTo.h>
#include <src/raze/algorithm/NotFn.h>
#include <src/raze/vx/dispatch/SizedSimdDispatcher.h>
#include <raze/options/Options.h>
#include <optional>


__RAZE_ALGORITHM_NAMESPACE_BEGIN

template <class _Traits_>
struct _Min_value : _Traits_ {
	template <class _Iterator_, class _Sentinel_, class Projection>
	struct __impl {
		_Iterator_ _iterator;
		_Sentinel_ _sentinel;
		Projection _proj;
		std::iter_value_t<_Iterator_> _lowest_value;

		constexpr explicit __impl(_Iterator_ __it, _Sentinel_ __sent, Projection __proj) noexcept :
			_iterator(__it), _sentinel(__sent), _proj(__proj), _lowest_value(*__it)
		{
			++_iterator;
		}

		template <class _Tag_>
		raze_always_inline raze_nodiscard constexpr bool operator()(_Tag_) noexcept {
			if (_iterator == _sentinel) return true;
			else {
				if (_proj(_lowest_value) > std::invoke(_proj, *_iterator)) _lowest_value = *_iterator;
				++_iterator;
				return false;
			}
		}

		raze_nodiscard constexpr raze_always_inline std::iter_value_t<_Iterator_> result() const noexcept {
			return _lowest_value;
		}
	};

	template <class _Tag_>
	struct __vectorized_min_value {
		template <class _Iterator_, class _Sentinel_, class Projection>
		raze_nodiscard raze_always_inline std::iter_value_t<_Iterator_> operator()(_Iterator_ __first, 
			_Sentinel_ __sentinel, Projection __proj) const noexcept requires(!vx::simd_type<_Tag_>)
		{
			std::iter_value_t<_Iterator_> __lowest_value = *__first;

			for (; ++__first != __sentinel;)
				if (__proj(__lowest_value) > __proj(*__first))
					__lowest_value = *__first;

			return __lowest_value;
		}

		template <class _Iterator_, class _Sentinel_, class Projection>
		raze_nodiscard raze_always_inline auto operator()(sizetype __aligned_size,
			sizetype __tail_size, _Iterator_ __first, _Sentinel_ __sentinel,
			Projection __proj) const noexcept requires(vx::simd_type<_Tag_>)
		{
			auto* __ptr = std::to_address(__first);
			raze_assume(__ptr != nullptr);

			const auto __aligned_end = __bytes_pointer_offset(__ptr, __aligned_size);
			auto __vmin = vx::load<_Tag_>(__ptr);
			__advance_bytes(__ptr, sizeof(_Tag_));

			if (__ptr != __aligned_end) {
				do {
					__vmin = vx::vertical_min(__proj(vx::load<_Tag_>(__ptr)), __proj(__vmin));
					__advance_bytes(__ptr, sizeof(_Tag_));
				} while (__ptr != __aligned_end);
			}
			else __vmin = __proj(__vmin);

			__seek_iter(__first, __ptr);
			auto __lowest_value = vx::horizontal_min(__vmin);

			for (; __first != __sentinel; ++__first)
				if (std::invoke(__proj, __lowest_value) > std::invoke(__proj, *__first))
					__lowest_value = *__first;

			return __lowest_value;
		}

		template <sizetype _AlignedSize_, sizetype _TailSize_,
			class _Iterator_, class _Sentinel_, class Projection>
		raze_nodiscard raze_always_inline auto operator()(std::integral_constant<sizetype, _AlignedSize_>,
			std::integral_constant<sizetype, _TailSize_>, _Iterator_ __first, _Sentinel_ __sentinel,
			Projection __proj) const noexcept requires(vx::simd_type<_Tag_>)
		{
			constexpr auto __iterations_aligned = _AlignedSize_ / sizeof(_Tag_);

			auto* __ptr = std::to_address(__first);
			raze_assume(__ptr != nullptr);

			auto __vmin = vx::load<_Tag_>(__ptr);
			auto __left = __iterations_aligned;

			__advance_bytes(__ptr, sizeof(_Tag_));

			if (--__left) {
				do {
					__vmin = vx::vertical_max(__proj(vx::load<_Tag_>(__ptr)), __proj(__vmin));
					__advance_bytes(__ptr, sizeof(_Tag_));
				} while (--__left);
			}
			else {
				__vmin = __proj(__vmin);
			}

			__seek_iter(__first, __ptr);
			auto __lowest_value = vx::horizontal_min(__vmin);

			if constexpr (_TailSize_ > 0) {
				for (; __first != __sentinel; ++__first)
					if (std::invoke(__proj, __lowest_value) > std::invoke(__proj, *__first))
						__lowest_value = *__first;
			}

			return __lowest_value;
		}
	};

	template <std::input_iterator _Iterator_, std::sentinel_for<_Iterator_> _Sentinel_, class Projection = std::identity>
	raze_nodiscard constexpr raze_always_inline std::optional<std::iter_value_t<_Iterator_>> operator()(_Iterator_ __first,
		_Sentinel_ __last, Projection __proj = {}) const noexcept
	{
		return __min_unchecked(traits::__uiter<_Sentinel_>(std::move(__first)),
			traits::__usent<_Iterator_>(std::move(__last)),
			traits::fwd_fn(__proj));
	}

	template <std::ranges::input_range Range, class Projection = std::identity>
	constexpr raze_always_inline std::optional<std::ranges::range_value_t<Range>> operator()(
		Range&& __range, Projection __proj = {}) const noexcept
			requires(!constexpr_sized_range<Range>)
	{
		return __min_unchecked(traits::__ubegin(__range),
			traits::__uend(__range), traits::fwd_fn(__proj));
	}

	template <std::ranges::input_range Range, class Projection = std::identity>
	constexpr raze_always_inline std::optional<std::ranges::range_value_t<Range>> operator()(Range&& __range,
		Projection __proj = {}) const noexcept requires(constexpr_sized_range<Range>)
	{
		return __min_unchecked(traits::__ubegin(__range),
			traits::__uend(__range), traits::fwd_fn(__proj),
			std::integral_constant<sizetype, __range_constexpr_size<Range>()>{});
	}
private:
	template <class _Iterator_, class _Sentinel_, class Projection>
	raze_nodiscard constexpr raze_always_inline std::optional<std::iter_value_t<_Iterator_>> __min_unchecked(
		_Iterator_ __first, _Sentinel_ __last, Projection __proj) const noexcept
	{
		__verify_range(__first, __last);

		using _TraitsType = decltype(this->traits());
		using _Value_ = std::iter_value_t<_Iterator_>;

		if (__first == __last) return std::nullopt;

		if constexpr (!options::always_scalar<_TraitsType>() && std::contiguous_iterator<_Iterator_>
			&& vectorizable_projection<Projection, _Iterator_>)
		{
			if not consteval {
				return std::optional<_Value_> { vx::__dispatch_sized_impl<__vectorized_min_value, _Value_, _Value_>(
					algorithm::distance(__first, __last) * sizeof(_Value_), __first, __last, __proj) };
			}
		}

		return std::optional<_Value_> { options::_unroller_t<_TraitsType, vx::scalar_tag>(__impl(__first, __last, __proj)) };
	}

	template <class _Iterator_, class _Sentinel_, class Projection, sizetype _Size_>
	raze_nodiscard constexpr raze_always_inline std::optional<std::iter_value_t<_Iterator_>> __min_unchecked(_Iterator_ __first,
		_Sentinel_ __last, Projection __proj, std::integral_constant<sizetype, _Size_> __size) const noexcept
	{
		__verify_range(__first, __last);

		using _TraitsType = decltype(this->traits());
		using _Value_ = std::iter_value_t<_Iterator_>;

		if (__first == __last) return std::nullopt;

		if constexpr (!options::always_scalar<_TraitsType>() && std::contiguous_iterator<_Iterator_>
			&& vectorizable_projection<Projection, _Iterator_>)
		{
			if not consteval {
				constexpr auto __bytes = std::integral_constant<sizetype, _Size_ * sizeof(_Value_)>{};
				return std::optional<_Value_> { vx::__dispatch_sized_impl<__vectorized_min_value,
					_Value_, _Value_>(__bytes, __first, __last, __proj) };
			}
		}

		return std::optional<_Value_> { options::_unroller_t<_TraitsType, vx::scalar_tag>(__impl(__first, __last, __proj)) };
	}
};

constexpr inline auto min = raze::options::function_with_traits<_Min_value>;

__RAZE_ALGORITHM_NAMESPACE_END
