#pragma once 

#include <raze/options/Options.h>
#include <src/raze/vx/Storage.h>

#if defined(raze_processor_x86)
#  include <src/raze/vx/hw/x86/arithmetic/Fms.h>
#endif // defined(raze_processor_x86)


__RAZE_MATH_NAMESPACE_BEGIN

template <class Options>
struct configurable_fms_t : options::conditional_callable<configurable_fms_t, Options> {
    template <class A, class B, class C>
        requires (vx::simd_type<A> || vx::simd_type<B> || vx::simd_type<C>)
    raze_nodiscard raze_always_inline auto operator()(const A& x, const B& y, const C& z) const noexcept {
        using V = std::conditional_t<vx::simd_type<A>, std::remove_cvref_t<A>,
            std::conditional_t<vx::simd_type<B>, std::remove_cvref_t<B>,
            std::remove_cvref_t<C>>>;

        return options::dispatch_call(*this, V(x), V(y), V(z));
    }

    template <vx::arithmetic_type T1, vx::arithmetic_type T2, vx::arithmetic_type T3>
    raze_nodiscard raze_always_inline auto operator()(const T1& x, const T2& y, const T3& z) const noexcept {
        using T = std::common_type_t<T1, T2, T3>;
        return options::dispatch_call(*this, T(x), T(y), T(z));
    }

    template <vx::arithmetic_type T>
    static raze_always_inline auto deferred_call(auto opts, const T& x, const T& y, const T& z) noexcept {
        using Mask = options::fetch_t<options::condition_key, Options>;

        if constexpr (!std::same_as<Mask, options::unknown_key>) {
            auto condition = opts[options::condition_key];

            if constexpr (Mask::has_alternative)
                return vx::fms_<arch::ISA::SSE2, T>(x, y, z, condition.mask(), condition.alternative());
            else
                return vx::fms_<arch::ISA::SSE2, T>(x, y, z, condition.mask());
        }
        else return vx::fms_<arch::ISA::SSE2, T>(x, y, z);
    }

    template <vx::simd_type V>
    static raze_always_inline auto deferred_call(auto opts, const V& x, const V& y, const V& z) noexcept {
        using Mask = options::fetch_t<options::condition_key, Options>;
        using Value = typename V::value_type;
        using Abi = typename V::abi_type;

        V r = x;

        auto chunk_op = [&] <class Chunk, class ... Args> (Chunk& chunk, Args&& ... args) raze_always_inline_lambda {
            chunk = vx::fms_<Abi::isa, Value>(vx::ustorage(chunk), vx::ustorage<Args>(args)...);
        };

        if constexpr (options::complete_mask<Mask>) {
            auto condition = opts[options::condition_key];

            if constexpr (Mask::has_alternative)
                r.__for_each_chunk(chunk_op, y.__storage().storage(), z.__storage().storage(), 
                    condition.mask().__storage().storage(), condition.alternative().__storage().storage());
            else
                r.__for_each_chunk(chunk_op, y.__storage().storage(), z.__storage().storage(),
                    condition.mask().__storage().storage());
        }
        else {
            r.__for_each_chunk(chunk_op, y.__storage().storage(), z.__storage().storage());
        }

        return r;
    }
};

constexpr inline auto fms = raze::options::functor<configurable_fms_t>;

__RAZE_MATH_NAMESPACE_END

