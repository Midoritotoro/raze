#pragma once 

__RAZE_MATH_NAMESPACE_BEGIN

constexpr inline auto pi = 3.14159265358979323846;

__RAZE_MATH_NAMESPACE_END
