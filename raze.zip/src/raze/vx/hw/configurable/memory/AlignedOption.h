#pragma once 

#include <raze/options/Options.h>


__RAZE_VX_NAMESPACE_BEGIN

struct aligned_mode {};
constexpr inline auto aligned = raze::options::flag(aligned_mode{});
struct aligned_option : raze::options::exact_option<aligned> {};
 
struct safe_mode {};
constexpr inline auto safe = raze::options::flag(safe_mode{});
struct safe_option : raze::options::exact_option<safe> {};

__RAZE_VX_NAMESPACE_END
