#pragma once 

#include <raze/options/Options.h>
#include <raze/vx/Abi.h>
#include <src/raze/vx/hw/configurable/memory/Store.h>
#include <src/raze/vx/hw/configurable/memory/Load.h>

#if defined(raze_processor_x86)
#  include <src/raze/vx/hw/x86/shape/Concat.h>
#endif // defined(raze_processor_x86)


__RAZE_VX_NAMESPACE_BEGIN

template <class T, class ... Ts>
using concatenated_simd = simd<typename T::value_type, resize_abi_t<typename T::abi_type,
    abi_t<T>::size + (abi_t<Ts>::size + ...)>>;

template <class ... Ts> 
concept effective_concatenation_available = same_abi_isa<Ts...> && !has_any_scalar_chunks<Ts...>;

template <class Options>
struct configurable_concat_t: options::conditional_callable<configurable_concat_t, Options> {
    template <simd_type T, class ... Ts>
    raze_nodiscard raze_always_inline concatenated_simd<T, Ts...> operator()(
        const T& x, const Ts& ... xs) const noexcept
            requires(sizeof...(Ts) > 0 && same_abi_isa<T, Ts...>)
    {
        return options::dispatch_call(*this, x, xs...);
    }

    template <simd_type T, class ... Ts>
    static raze_always_inline auto deferred_call(auto opts, const T& x, const Ts& ... xs) noexcept {
        using Concatenated = concatenated_simd<T, Ts...>;
        using Value = typename Concatenated::value_type;
        using Abi = typename Concatenated::abi_type;

        Concatenated r;
        
        Value arr[Abi::size];
        Value* ptr = arr;

        store(ptr, x);
        ptr += x.size();

        ([&]() raze_always_inline_lambda { store(ptr, xs); ptr += xs.size(); }(), ...);
        r = load<Concatenated>(arr);

        return r;
    }
};

/**
 * @ingroup raze_vx_shape
 * @memberof raze::vx
 * @hideinitializer
 * @brief Concatenates multiple SIMD vectors into a single larger SIMD vector.
 *
 * Combines the elements of two or more SIMD vectors end-to-end. All input vectors
 * must share the same ABI ISA. The resulting vector
 * has a width equal to the sum of the input widths.
 *
 * ### Declarations
 * ```cpp
 * template <simd_type T, class ... Ts>
 * concatenated_simd<T, Ts...> operator()(const T& x, const Ts& ... xs) const noexcept;
 * ```
 *
 * ### Template Parameters
 * - `T` — The first SIMD type.
 * - `Ts...` — The remaining SIMD types.
 *
 * ### Parameters
 * - `x` — The first SIMD vector.
 * - `xs...` — The remaining SIMD vectors to concatenate.
 *
 * ### Constraints
 * - `sizeof...(Ts) > 0` — At least two vectors must be provided.
 * - All input types must share the same ABI ISA (`same_abi_isa<T, Ts...>`).
 *
 * ### Mask semantics
 * **Not supported.**
 *
 * ### Return value
 * A SIMD vector of type `concatenated_simd<T, Ts...>` containing the elements of the inputs
 * in the order they were passed.
*/
constexpr inline auto concat = options::functor<configurable_concat_t>;

__RAZE_VX_NAMESPACE_END
